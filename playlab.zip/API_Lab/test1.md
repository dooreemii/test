# 페이지 및 요약

### 요약

[HonKit](https://honkit.netlify.app/GLOSSARY.html#honkit "Honkit은 GitHub/Git 및 Markdown(또는 AsciiDoc)을 사용하여 아름다운 책을 만들기 위한 명령줄 도구입니다.") 은 `SUMMARY.md`파일을 사용하여 책의 장과 하위 장의 구조를 정의합니다. 이 `SUMMARY.md`파일은 책의 목차를 생성하는 데 사용됩니다.

의 형식은 `SUMMARY.md`링크 목록일 뿐입니다. 링크의 제목은 장의 제목으로 사용되며 링크의 대상은 해당 장의 파일에 대한 경로입니다.

상위 챕터에 중첩된 목록을 추가하면 하위 챕터가 생성됩니다.

##### 간단한 예

```
# Summary

* [Part I](part1/README.md)
    * [Writing is nice](part1/writing.md)
    * [HonKit is nice](part1/honkit.md)
* [Part II](part2/README.md)
    * [We love feedback](part2/feedback_please.md)
    * [Better tools for authors](part2/better_tools.md)
```

각 장에는 전용 페이지( `part#/README.md`)가 있으며 하위 장으로 나뉩니다.

##### 앵커

목차의 챕터는 앵커를 사용하여 파일의 특정 부분을 가리킬 수 있습니다.

```
# Summary

### Part I

* [Part I](part1/README.md)
    * [Writing is nice](part1/README.md#writing)
    * [HonKit is nice](part1/README.md#honkit)
* [Part II](part2/README.md)
    * [We love feedback](part2/README.md#feedback)
    * [Better tools for authors](part2/README.md#tools)
```

##### 부속

목차는 제목 또는 수평선으로 구분된 부분으로 나눌 수 있습니다.

```
# Summary

### Part I

* [Writing is nice](part1/writing.md)
* [HonKit is nice](part1/honkit.md)

### Part II

* [We love feedback](part2/feedback_please.md)
* [Better tools for authors](part2/better_tools.md)

----

* [Last part without title](part3/title.md)
```

파트는 챕터 그룹일 뿐이며 전용 페이지가 없지만 테마에 따라 내비게이션에 표시됩니다.

### 페이지

#### 마크다운 구문

대부분의 [HonKit](https://honkit.netlify.app/GLOSSARY.html#honkit "Honkit은 GitHub/Git 및 Markdown(또는 AsciiDoc)을 사용하여 아름다운 책을 만들기 위한 명령줄 도구입니다.") 용 파일은 기본적으로 Markdown 구문을 사용합니다. [HonKit](https://honkit.netlify.app/GLOSSARY.html#honkit "Honkit은 GitHub/Git 및 Markdown(또는 AsciiDoc)을 사용하여 아름다운 책을 만들기 위한 명령줄 도구입니다.") 은 페이지 구조를 추론합니다. [사용된 구문은 GitHub Flavored Markdown 구문](https://guides.github.com/features/mastering-markdown/) 과 유사 합니다 . [AsciiDoc 구문](https://honkit.netlify.app/asciidoc.md) 을 선택할 수도 있습니다 .

##### 챕터 파일의 예

```
# Title of the chapter

This is a great introduction.

## Section 1

Markdown will dictates _most_ of your **book's structure**

## Section 2

...
```

#### 서문

페이지에는 선택적 머리말이 포함될 수 있습니다. 페이지의 설명을 정의하는 데 사용할 수 있습니다. 머리말은 파일의 첫 번째 항목이어야 하며 삼중 파선 사이에 유효한 YAML 세트 형식을 취해야 합니다. 다음은 기본적인 예입니다.

```
---
description: This is a short description of my page
---

# The content of my page
...
```

머리말은 자신의 변수를 정의할 수 있으며 [템플릿](https://honkit.netlify.app/GLOSSARY.html#templating "HonKit uses the Nunjucks templating language to process pages and theme's templates.") 에서 사용할 수 있도록 [페이지 변수](https://honkit.netlify.app/templating/variables.html) 에 추가됩니다 .
